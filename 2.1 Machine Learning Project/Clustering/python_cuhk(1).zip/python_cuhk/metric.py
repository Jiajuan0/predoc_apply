import numpy as np
from numpy.lib.setup import configuration

def __confusion_matrix(y_pred, y_true): 
    matrix = np.zeros((3, 3))
    for (p, t) in zip(y_pred, y_true): 
        matrix[p, t] += 1
    return matrix
    
def purity(y_pred, y_true): 
    """
    Assumes `y_true`and `y_pred`are ints that starts from 0
    """

    confusion = __confusion_matrix(y_pred, y_true)
    return sum(np.max(confusion, axis=1)) / len(y_pred)

def nmi(y_pred, y_true): 
    """
    Assumes `y_true`and `y_pred`are ints that starts from 0
    """
    
    confusion = __confusion_matrix(y_pred, y_true)

    hist_pred = np.sum(confusion, axis=1)
    hist_true = np.sum(confusion, axis=0)
    
    confusion[confusion == 0] = np.nan
    MI = np.sum(
        np.nan_to_num(confusion * np.log2(len(y_pred) * confusion / hist_pred[:, np.newaxis] / hist_true[np.newaxis, :]), nan=0)
    ) / len(y_pred)
    
    HO = - np.sum(
        hist_pred / len(y_pred) * np.log2(hist_pred / len(y_pred))
    )
    HC = -np.sum(
        hist_true / len(y_pred) * np.log2(hist_true / len(y_pred))
    )
    return MI/((HO + HC)/2)
    
def RI(y_pred, y_true): 
    """
    Assumes `y_true`and `y_pred`are ints that starts from 0
    """

    tn_fn_fp_tp = [0, 0, 0, 0]
    for i in range(len(y_pred)):
        for j in range(i+1, (len(y_pred))):
            index = (y_pred[i] == y_pred[j]) * 2 + (y_true[i] == y_true[j]) 
            tn_fn_fp_tp[index] += 1

    return (tn_fn_fp_tp[0] + tn_fn_fp_tp[2]) / (sum(tn_fn_fp_tp))
