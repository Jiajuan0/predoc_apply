from sys import flags
import numpy as np
from numpy.core.fromnumeric import clip
from numpy.lib.function_base import average
from numpy.ma.core import set_fill_value
from time import time

import metric

class Cluster:
    def __init__(self, n_clusters) :
        self.n_clusters = n_clusters
        self.labels = []
        
    def fit(self, X): 
        pass
    
    def predict(self, X): 
        pass
    
    def score(self, y, metric): 
        return metric(self.labels, y)

    
    def report(self, X, y): 
        start = time()
        iter = self.fit(X)
        interval = time() - start
        
        print("Name: ", self.__class__)
        print("Fit time", interval)
        print("Iteration: ", iter)
        
        print("centriods:")
        print(self.centroids)
        
        print("Purity: ", self.score(y, metric.purity))
        print("NMI: ", self.score(y, metric.nmi))
        print("RI: ", self.score(y, metric.RI))
        
        print("---")

    
    
class KMeans(Cluster): 
    def __init__(self, n_clusters, init_means=None):
        super().__init__(n_clusters)
        self.centroids = init_means
        self.labels = None
        
    def _set_up(self, X): 
        if self.centroids is None:
            self.centroids = X[:self.n_clusters]
        self.labels = np.zeros(len(X))
    
    def _closest_labels(self, X):
        square_distances = np.square(X - self.centroids[:, np.newaxis, :]).sum(axis=2) # see numpy documents for broadcast rule with dimension 1
        return np.argmin(np.nan_to_num(square_distances, nan=np.inf), axis=0)
    
    def _fit_centroids(self, X):
        return np.array(
            [np.mean(X[self.labels == k], axis=0) for k in range(self.n_clusters)]
        )
        
    def _update_labels(self, X): 
        new_labels = self._closest_labels(X)
        flag = not (new_labels == self.labels).all()
        self.labels = new_labels
        return flag
    
    def _update_centroids(self, X):
        self.centroids = self._fit_centroids(X)

    def fit(self, X): 
        self._set_up(X)

        count = 0
        while True:
            if not self._update_labels(X):
                break
            self._update_centroids(X)
            count += 1
            
        return count
            
    def predict(self, X):
        return self._closest_labels(X)
    
    
class SoftKMeans(KMeans):
    def __init__(self, n_clusters, beta, init_means=None):
        super().__init__(n_clusters, init_means=init_means)
        self.beta = beta
    
    def __responsibilities(self, X): 
        distances = np.sqrt((X - self.centroids[:, np.newaxis, :])**2).sum(axis=2) # d(i, j) = d(µ_i, X_j)
        return np.exp(-self.beta * distances) / np.sum(np.exp(-self.beta * distances), axis=0)

    
    def _closest_labels(self, X):
        repsonsbilities = self.__responsibilities(X)
        return np.argmax(np.nan_to_num(repsonsbilities, nan=np.inf), axis=0) 
    
    def _fit_centroids(self, X):
        responsbilities = self.__responsibilities(X)
        return np.array(
            [np.average(X, weights=responsbilities[k], axis=0)
             for k in range(self.n_clusters)]
        )
        
class GMM(Cluster):
    def __init__(self, n_clusters, init_means=None, init_cov=None, init_mix=None):
        super().__init__(n_clusters)
        self.centroids = init_means
        self.cov = init_means
        self.mix = init_means
        
        self.responsibilties = None
        
    def __gaussian(self, X, mu, sigma):
        shifted = X - mu[:, np.newaxis, :] # (X - µ)_{knj}
        invsig = np.linalg.inv(sigma) # ∑^(-1)_{kjm}
        
        # (2π)^{-k/2} det(∑)^{1/2}_{kn}
        first = (2 * np.pi)**(-len(mu)/2) * np.sqrt(np.abs(np.linalg.det(sigma)))
        
        # exp(...)_{kn}
        # second = np.exp(
        #     (-1/2) * np.sum(
        #         shifted.dot(invsig) * shifted, axis=-1
        #     )
        # )
        
        second = np.exp(
            (-1/2) * np.einsum(
                "kni,kni->kn",
                np.einsum("kni,kij->knj", shifted, invsig), 
                shifted
            )
        )
        
        return first[:, np.newaxis] * second
        
    def _set_up(self, X):
        if self.centroids is None:
            self.centroids = X[: self.n_clusters]
            
        if self.cov is None:
            self.cov = np.repeat(np.eye(X.shape[1])[np.newaxis, :, :], self.n_clusters, axis=0)
            
        if self.mix is None:
            self.mix = np.ones(self.n_clusters) / self.n_clusters
            
    def _e_step(self, X): 
        gaussian = self.__gaussian(X, self.centroids, self.cov)
        responsibilties = self.mix[:, np.newaxis] * gaussian
        
        self.responsibilties = responsibilties / np.sum(responsibilties, axis=0)
    
    
    def _update_labels(self, X): 
        self.labels = np.argmax(np.nan_to_num(self.responsibilties, nan=np.inf), axis=0)        
        
    def _m_step(self, X): 
        self.centroids = np.array(
            [np.average(X, weights=self.responsibilties[k], axis=0) for k in range(self.n_clusters)]
            )
        
        self.cov = np.array([
            np.average(
                (X[:, :, np.newaxis] - self.centroids[k]) * (X[:, np.newaxis, :] - self.centroids[k]), 
                weights=self.responsibilties[k], 
                axis=0
            ) for k in range(self.n_clusters)
        ])
        
        self.mix = np.sum(self.responsibilties, axis=1) / len(X)
        
    def fit(self, X):
        self._set_up(X)
        
        for i in range(5):
            self._e_step(X)
            self._m_step(X)
            
        self._update_labels(X)

        return 5
        
class AccelaratedKMeans(KMeans):
    def __init__(self, n_clusters, init_means=None):
        super().__init__(n_clusters, init_means=init_means)
        self.dc = []

    def _set_up(self, X):
        if self.centroids is None:
            self.centroids = X[:self.n_clusters]

        super()._update_labels(X)

        self._init_l(X)
        self.u = np.min(self.l, axis=1)

        self._update_dist_mat()
        self.r = np.repeat(True, len(X))
        # self._update_labels(X)
        
    def _init_l(self, X):
        self.l = np.array([[
            np.sqrt(np.sum(np.square(x - c))) for c in self.centroids
            ] for x in X])
        
    def _update_dist_mat(self):
        self.dc = np.array([ [np.sqrt(np.sum(np.square(c1 - c2))) for c2 in self.centroids] for c1 in self.centroids])
        np.fill_diagonal(self.dc, np.inf)
    
        
    def _update_labels(self, X):
        flag = False
        
        self._update_dist_mat()
        self.s = (1/2) * np.min(
                self.dc, axis=0
            )
        for (i, x) in enumerate(X):
            if self.u[i] <= self.s[self.labels[i]]:
                continue
            
            for (j, c) in enumerate(self.centroids):
                if (c == self.labels[i]).all() or self.u[i] > self.l[i, j] or self.u[i] > (1/2) * self.dc[self.labels[i], j]:
                    continue
                
                if self.r[i]:
                    d = np.sqrt(np.sum(np.square(x - self.labels[i])))
                    self.r[i] = False
                else:
                    d = self.u[i]
                    
                if d > self.l[i, j] or d > (1/2) * self.dc[self.labels[i], j]:
                    d2 = np.sqrt(np.sum(np.square(x - self.centroids[j])))
                    if d2 < d:
                        self.labels[i] = j
                        flag = True

        return flag
        

    def _update_centroids(self, X):
        m = self._fit_centroids(X)
        d = np.sqrt(np.sum(np.square(m - self.centroids), axis=1))
        
        self.l = clip(self.l - d, a_min=0, a_max=np.inf)
        self.u += d[self.labels]
        self.r = np.repeat(True, len(X))
        self.centroids = m

