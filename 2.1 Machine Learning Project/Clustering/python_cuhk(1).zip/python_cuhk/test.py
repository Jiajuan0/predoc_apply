import unittest
import numpy as np
import csv

import clusters
import metric

class TestClusters(unittest.TestCase):
    def setUp(self):
        data = np.genfromtxt("seeds_dataset.txt")
        self.X = data[:, :-1]
        self.y = (data[:, -1] - 1).astype(int) # data class starts from 1

        self.k_means = clusters.KMeans(3)
        self.soft_k_means = clusters.SoftKMeans(3, 0.2)
        self.k_acc = clusters.AccelaratedKMeans(3)
        self.gmm = clusters.GMM(3)

    @unittest.skip
    def test_k_means(self):
        self.k_means.fit(self.X)
        print(self.k_means.score(self.y, metric.purity))
        print(self.k_means.score(self.y, metric.nmi))
        print(self.k_means.score(self.y, metric.RI))

    @unittest.skip
    def test_gmm(self):
        self.gmm.fit(self.X)
        print(self.gmm.score(self.y, metric.purity))
        print(self.gmm.score(self.y, metric.nmi))
        print(self.gmm.score(self.y, metric.RI))

    @unittest.skip
    def test_acc(self):
        self.k_acc.fit(self.X)
        print(self.k_acc.score(self.y, metric.purity))
        print(self.k_acc.score(self.y, metric.nmi))
        print(self.k_acc.score(self.y, metric.RI))
        # print(self.k_acc.labels)
        
    def test_report(self):
        self.k_means.report(self.X, self.y)
        self.soft_k_means.report(self.X, self.y)
        self.k_acc.report(self.X, self.y)
        self.gmm.report(self.X, self.y)